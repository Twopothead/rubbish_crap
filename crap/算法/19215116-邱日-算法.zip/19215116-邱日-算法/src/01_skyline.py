import itertools
from functools import cmp_to_key
import heapq
from queue import PriorityQueue


class Solution(object):

    def getSkyline(self, buildings):
        """
        :type buildings: List[List[int]]
        :rtype: List[List[int]]
        """
        cp = list(itertools.chain.from_iterable(
            [[[b[0], 0], [b[1], 0]] for b in buildings]))
        for b in buildings:
            for c in cp:
                if b[0] <= c[0] < b[1]:
                    c[1] = max(c[1], b[2])
        new = sorted(cp)
        res = [[-1, -1]]
        for pt in new:
            if pt[1] != res[-1][1]:
                res.append(pt)
        return res[1:]

    def getSkyline2(self, buildings):
        """
        O(nlogn)
        :type buildings: List[List[int]]
        :rtype: List[List[int]]
        """
        cp = sorted(list(itertools.chain.from_iterable(
            [[[b[0], -b[2]], [b[1], b[2]]] for b in buildings])))
        heap = []
        res = [[-1, -1]]
        for pt in cp:
            if pt[1] < 0:
                heapq.heappush(heap, pt[1])
            else:
                heap.remove(-pt[1])
                heapq.heapify(heap)
            if len(heap) > 0:
                if res[-1][1] != -heap[0]:
                    res.append([pt[0], -heap[0]])
            else:
                res.append([pt[0], 0])
        return res[1:]

    def getSkyline3(self, buildings):
        if len(buildings) > 1:
            mid = len(buildings) // 2
            left = self.getSkyline3(buildings[:mid])
            right = self.getSkyline3(buildings[mid:])
            return self.merge(left, right)
        return [[buildings[0][0], buildings[0][2]], [buildings[0][1], 0]]

    def merge(self, left, right):
        h1, h2, i, j, skyLine = 0, 0, 0, 0, []
        while i < len(left) and j < len(right):
            if left[i][0] < right[j][0]:
                pt = [left[i][0], max(left[i][1], h2)]
                h1 = left[i][1]
                i += 1
            elif left[i][0] > right[j][0]:
                pt = [right[j][0], max(right[j][1], h1)]
                h2 = right[j][1]
                j += 1
            else:
                pt = [left[i][0], max(left[i][1], right[j][1])]
                h1 = left[i][1]
                h2 = right[j][1]
                i += 1
                j += 1
            if len(skyLine) == 0 or skyLine[-1][1] != pt[1]:
                skyLine.append(pt)
        skyLine.extend(left[i:] or right[j:])
        return skyLine
