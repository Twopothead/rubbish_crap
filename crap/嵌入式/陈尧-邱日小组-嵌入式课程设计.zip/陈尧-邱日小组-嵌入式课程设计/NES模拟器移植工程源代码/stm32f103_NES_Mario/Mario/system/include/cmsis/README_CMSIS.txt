* -------------------------------------------------------------------
* Copyright (C) 2011-2014 ARM Limited. All rights reserved.  
* 
* Date:        17 February 2014  
* Revision:    V4.00 
*  
* Project:     Cortex Microcontroller Software Interface Standard (CMSIS)
* Title:       Release Note for CMSIS
*
* -------------------------------------------------------------------

These files are the CMSIS Core Support and CMSIS DSP Include Files.

To save space, from the complete ARM package (CMSIS-SP-00300-r4p0-00rel0.zip)
only the CMSIS/Include folder was used here.
