此模板是根据Eclipse的ARM模板转化而来，根据不同的芯片请做相应的修改。
需要修改的内容
1. ldscripts/mem.ld          -- 芯片容量
2. JLinkCommandFile.jlink    -- JLinkExe操作文件
3. makefile
