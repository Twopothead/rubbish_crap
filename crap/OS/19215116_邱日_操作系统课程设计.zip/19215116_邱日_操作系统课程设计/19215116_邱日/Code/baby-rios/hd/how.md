- Open a terminal ,then 
	$ bximage
- Input "hd", "flat", "10", "rios_hd.img"
- Then a blank 10MB hard disk image will be made.
