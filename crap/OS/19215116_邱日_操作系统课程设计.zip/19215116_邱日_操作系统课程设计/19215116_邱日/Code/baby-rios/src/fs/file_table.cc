#include <rios/fs.h>
struct file file_table[NR_FILE];
/* this is system-wide file table */