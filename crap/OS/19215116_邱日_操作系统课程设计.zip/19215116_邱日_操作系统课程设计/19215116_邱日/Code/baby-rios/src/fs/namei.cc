#include <rios/namei.h>

void dir_namei(){

}

/*	namei()
 * get the inode of a specific pathname
 */
struct  m_inode * namei(const char * pathname)
{
	char c;
	const char * basename;
	struct m_inode * dir;
	// while()
	return dir;
};