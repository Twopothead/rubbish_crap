#include <rios/ramdisk.h>

void init_ramdisk()
{
	char tmp;
	

}