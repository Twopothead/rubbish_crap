#ifndef _NAMEI_H
#define _NAMEI_H
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#include <rios/fs.h>
#include <asm/x86.h>	
#include <rios/bitmap.h>
#include <rios/ramdisk.h>



	
#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif