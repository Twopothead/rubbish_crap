#ifndef _TIMER_H
#define _TIMER_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void do_timer();



#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif