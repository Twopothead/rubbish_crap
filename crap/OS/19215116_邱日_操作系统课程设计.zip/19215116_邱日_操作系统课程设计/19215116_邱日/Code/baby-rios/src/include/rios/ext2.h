#ifndef _EXT2_H
#define _EXT2_H
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


	

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif