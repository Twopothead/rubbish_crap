RiOS kernel
============
 
This is a naive x86 kernel. If you are interested in this
project and would like to help, please give me a pull request
, any and all contributions will be appreciated. 
You can also donate me a cup of coffee AT 3103204417@qq.com.

##### Copyright (C) 2018 Frank Curie (邱日)


